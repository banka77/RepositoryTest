﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Гебель4ПР
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
            Polygon l1 = new Polygon();
            l1.Stroke = Brushes.Black;
            l1.Fill = Brushes.White;
            l1.StrokeThickness = 2;
            System.Windows.Point point1 = new System.Windows.Point(382, 70);
            System.Windows.Point point2 = new System.Windows.Point(250, 300);
            System.Windows.Point point3 = new System.Windows.Point(510, 300);
            PointCollection myPointCollection = new PointCollection();
            myPointCollection.Add(point1);
            myPointCollection.Add(point2);
            myPointCollection.Add(point3);
            l1.Points = myPointCollection;
            grid2.Children.Add(l1);

            Line ln1 = new Line();
            ln1.Stroke = Brushes.Black;
            ln1.Fill = Brushes.Black;
            ln1.X1 = 382;
            ln1.Y1 = 70;
            ln1.X2 = 382;
            ln1.Y2 = 280;
            ln1.StrokeDashArray = new DoubleCollection { 5, 3 };
            grid2.Children.Add(ln1);

            Line ln2 = new Line();
            ln2.Stroke = Brushes.Black;
            ln2.Fill = Brushes.Black;
            ln2.X1 = 510;
            ln2.Y1 = 300;
            ln2.X2 = 380;
            ln2.Y2 = 250;
            ln2.StrokeDashArray = new DoubleCollection {5, 3};
            grid2.Children.Add(ln2);

            Line ln3 = new Line();
            ln3.Stroke = Brushes.Black;
            ln3.Fill = Brushes.Black;
            ln3.X1 = 250;
            ln3.Y1 = 300;
            ln3.X2 = 380;
            ln3.Y2 = 252;
            ln3.StrokeDashArray = new DoubleCollection {5, 3};
            grid2.Children.Add(ln3);

            Line ln4 = new Line();
            ln4.Stroke = Brushes.Black;
            ln4.Fill = Brushes.Black;
            ln4.X1 = 280;
            ln4.Y1 = 288;
            ln4.X2 = 380;
            ln4.Y2 = 190;
            ln4.StrokeDashArray = new DoubleCollection { 5, 3 };
            grid2.Children.Add(ln4);

            Line ln5 = new Line();
            ln5.Stroke = Brushes.Black;
            ln5.Fill = Brushes.Black;
            ln5.X1 = 480;
            ln5.Y1 = 288;
            ln5.X2 = 380;
            ln5.Y2 = 190;
            ln5.StrokeDashArray = new DoubleCollection { 5, 3 };
            grid2.Children.Add(ln5);

            Ellipse el3 = new Ellipse();
            el3.Stroke = Brushes.Black;
            el3.Fill = Brushes.Black;
            el3.Width = 8;
            el3.Height = 8;
            el3.Margin = new Thickness(80, 250, 100, 100);
            grid2.Children.Add(el3);
        }
    }
}
