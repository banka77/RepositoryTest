﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Гебель4ПР
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            Rectangle el = new Rectangle();
            el.Width = 150;
            el.Height = 150;
            el.VerticalAlignment = VerticalAlignment.Center;
            el.Fill = Brushes.White;
            el.Stroke = Brushes.Black;
            el.StrokeThickness = 15;
            grid1.Children.Add(el);


            Rectangle il = new Rectangle();
            il.Width = 200;
            il.Height = 60;
            il.Fill = Brushes.Black;
            il.Stroke = Brushes.Black;
            il.StrokeThickness = 3;
            grid1.Children.Add(il);
            il.Margin= new Thickness(150, -40, 100, 100);




            Rectangle al = new Rectangle();
            al.Width = 50;
            al.Height = 150;
            al.Fill = Brushes.Black;
            al.Stroke = Brushes.Black;
            al.StrokeThickness = 3;
            grid1.Children.Add(al);
            al.Margin = new Thickness(300, 100, 100, 100);


            Polygon pl1 = new Polygon();
            pl1.Stroke = Brushes.Blue;
            pl1.Fill = Brushes.Blue;
            System.Windows.Point point1 = new System.Windows.Point(382, 130);
            System.Windows.Point point2 = new System.Windows.Point(180, 140);
            System.Windows.Point point3 = new System.Windows.Point(250, 170);
            System.Windows.Point point4 = new System.Windows.Point(379, 160);
            PointCollection myPointCollection = new PointCollection();
            myPointCollection.Add(point1);
            myPointCollection.Add(point2);
            myPointCollection.Add(point3);
            myPointCollection.Add(point4);
            pl1.Points = myPointCollection;
            grid1.Children.Add (pl1);
        }
    }
}
