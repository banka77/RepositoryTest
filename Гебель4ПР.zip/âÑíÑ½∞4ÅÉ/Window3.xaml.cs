﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Гебель4ПР
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        public Window3()
        {
            InitializeComponent();
            Line l1 = new Line();
            l1.Stroke = Brushes.Black;
            l1.Fill = Brushes.Black;
            l1.StrokeThickness = 1;
            l1.X1 = 400;
            l1.Y1 = 50;
            l1.X2 = 400;
            l1.Y2 = 350;
            grid3.Children.Add(l1);

            Line l2 = new Line();
            l2.Stroke = Brushes.Black;
            l2.Fill = Brushes.Black;
            l2.StrokeThickness = 1;
            l2.X1 = 250;
            l2.Y1 = 200;
            l2.X2 = 550;
            l2.Y2 = 200;
            grid3.Children.Add(l2);
        }
    }
}
